import{F as e,L as t,Mt as n,d as r,it as i,m as a,u as o,x as s}from"./D_VDJmhl.js";import{d as c,n as l}from"#entry";var u={class:`right-tab`},d={class:`flex flex-wrap h-30`},f={width:`20`,height:`100%`,viewBox:`0 0 60 400`},p=`
  M 30 10
  C 55 30, 55 70, 30 90
  C 5 110, 5 150, 30 170
  C 55 190, 55 230, 30 250
  C 5 270, 5 310, 30 330
  C 55 350, 55 390, 30 390
`,m=Object.assign(l(s({__name:`RightTab`,setup(s){let l=i(null),m=i(0),{y:h}=c(),g=o(()=>{let e=document.documentElement.scrollHeight-window.innerHeight;return e<=0?0:Math.min(1,h.value/e)});e(()=>{l.value&&(m.value=l.value.getTotalLength())});let _=o(()=>({strokeDasharray:m.value,strokeDashoffset:m.value*(1-g.value)}));return(e,i)=>(t(),a(`div`,u,[r(`div`,d,[(t(),a(`svg`,f,[r(`path`,{ref_key:`trackRef`,ref:l,d:p,fill:`none`,class:`track`},null,512),r(`path`,{d:p,fill:`none`,class:`thumb`,style:n(_.value)},null,4)]))])]))}}),[[`__scopeId`,`data-v-75337ba2`]]),{__name:`RightTab`});export{m as t};