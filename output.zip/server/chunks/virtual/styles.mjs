const interopDefault = r => r.default || r || [];
const styles = {
  "../node_modules/.pnpm/nuxt@4.5.2_@babel+plugin-sy_55fd0a4c738e062ccc2ec332655be8a2/node_modules/nuxt/dist/app/entry.js": () => import('../build/entry-styles.BvYgGaWL.mjs').then(interopDefault),
  "components/BackToTop.vue": () => import('../build/BackToTop-styles.DOz60eZb.mjs').then(interopDefault),
  "components/Notice.vue": () => import('../build/Notice-styles.CbxEVrC7.mjs').then(interopDefault),
  "components/ThemeToggle.vue": () => import('../build/ThemeToggle-styles.B6vdcqlt.mjs').then(interopDefault),
  "../node_modules/.pnpm/@nuxtjs+mdc@0.23.2_magic-st_475ece085b1e2a81f5f0a2791d2afdc0/node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProsePre.vue": () => import('../build/ProsePre-styles.DChF6eHF.mjs').then(interopDefault),
  "pages/index.vue": () => import('../build/index-styles.D3Ds42X7.mjs').then(interopDefault),
  "../node_modules/.pnpm/nuxt@4.5.2_@babel+plugin-sy_55fd0a4c738e062ccc2ec332655be8a2/node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.DRI5VVhH.mjs').then(interopDefault),
  "../node_modules/.pnpm/nuxt@4.5.2_@babel+plugin-sy_55fd0a4c738e062ccc2ec332655be8a2/node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.BrsBDRe8.mjs').then(interopDefault),
  "components/Search.vue": () => import('../build/Search-styles.BnKQ9ftS.mjs').then(interopDefault),
  "components/TypeDropdown.vue": () => import('../build/TypeDropdown-styles.BDGO43-X.mjs').then(interopDefault),
  "components/SpinCircle.vue": () => import('../build/SpinCircle-styles.BD_tJa_j.mjs').then(interopDefault),
  "layouts/default.vue": () => import('../build/default-styles.DMb8ALzQ.mjs').then(interopDefault),
  "layouts/index-layout.vue": () => import('../build/index-layout-styles.UYBpEFy0.mjs').then(interopDefault),
  "layouts/slug-layout.vue": () => import('../build/slug-layout-styles.DISK1Fth.mjs').then(interopDefault),
  "components/RightTabWithNav.vue": () => import('../build/RightTabWithNav-styles.D76oYDI3.mjs').then(interopDefault),
  "components/TocFanNav.vue": () => import('../build/TocFanNav-styles.B2KZGSPx.mjs').then(interopDefault),
  "components/FloatingMenu.vue": () => import('../build/FloatingMenu-styles.BqmaB_jr.mjs').then(interopDefault),
  "components/RightRail.vue": () => import('../build/RightRail-styles.B3M5E-Ra.mjs').then(interopDefault),
  "components/FanVirtualList.vue": () => import('../build/FanVirtualList-styles.wm_W7cfq.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
